create definer = root@localhost trigger company_before_delete
    before delete
    on company
    for each row
BEGIN

	UPDATE plant
	SET plant.Company_ID = NULL
	WHERE plant.Company_ID = OLD.Company_ID;
	
	UPDATE user
	SET user.Company_ID = null
	WHERE user.Company_ID = OLD.Company_ID;
	
	
END;

