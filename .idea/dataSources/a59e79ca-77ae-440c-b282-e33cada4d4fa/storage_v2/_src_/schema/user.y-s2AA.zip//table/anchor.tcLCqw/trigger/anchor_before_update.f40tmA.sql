create definer = root@localhost trigger anchor_before_update
    before update
    on anchor
    for each row
BEGIN
    -- Save current data to anchor_history
		INSERT INTO anchor_history (Anchor_ID, Anchor_Name, Room_ID, Anchor_Status)
		VALUES (OLD.anchor_ID, OLD.anchor_Name, OLD.room_ID, OLD.anchor_Status);
    -- The actual update on the anchor table occurs after this trigger
END;

