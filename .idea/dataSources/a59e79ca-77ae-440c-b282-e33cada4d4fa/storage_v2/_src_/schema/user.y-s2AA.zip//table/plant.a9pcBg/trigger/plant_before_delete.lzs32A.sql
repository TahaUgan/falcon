create definer = root@localhost trigger plant_before_delete
    before delete
    on plant
    for each row
BEGIN

	UPDATE place
	SET place.Plant_ID = NULL
	WHERE place.Plant_ID = OLD.Plant_ID;
	
	UPDATE server
	SET server.Server_Status = "Unknown"
	WHERE server.Server_ID = OLD.Server_ID;
	
END;

