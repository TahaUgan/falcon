create definer = root@localhost trigger plant_before_update
    before update
    on plant
    for each row
BEGIN

		UPDATE plant_history
		SET plant_history.Is_Last = Null
		WHERE plant_history.Plant_ID = OLD.Plant_ID AND plant_history.Is_Last = 'Last';

		INSERT INTO plant_history (plant_history.Plant_ID, plant_history.Plant_Name, plant_history.Company_ID, plant_history.Server_ID, plant_history.Is_Last)
		VALUES (OLD.Plant_ID, OLD.Plant_Name, OLD.Company_ID, OLD.Server_ID, 'Last');
		
		

END;

