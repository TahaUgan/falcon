create
    definer = root@localhost function anchor_last_active(Given_Anchor_ID int) returns datetime reads sql data
BEGIN
    DECLARE last_date DATETIME;

    -- Check if the anchor status is 'active'
    IF EXISTS (
        SELECT 1
        FROM anchor
        WHERE anchor.Anchor_ID = Given_Anchor_ID AND anchor.Anchor_Status = 'active'
    ) THEN
        -- Set last_date to the current date and time
        SET last_date = NOW();
    ELSE
        -- Retrieve the most recent Change_Date where status was 'Active'
        SELECT anchor_history.Change_Date
        INTO last_date
        FROM anchor_history
        WHERE anchor_history.Anchor_ID = Given_Anchor_ID AND anchor_history.Anchor_Status = 'Active'
        ORDER BY anchor_history.Change_Date DESC
        LIMIT 1;
    END IF;

    -- Return the last_date
    RETURN last_date;
END;

