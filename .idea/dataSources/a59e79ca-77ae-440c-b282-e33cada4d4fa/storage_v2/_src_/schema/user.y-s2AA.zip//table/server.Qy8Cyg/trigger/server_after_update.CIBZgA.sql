create definer = root@localhost trigger server_after_update
    after update
    on server
    for each row
BEGIN
    IF NEW.Server_Status IN ('Inactive', 'Unknown') AND NEW.Server_Status != OLD.Server_Status THEN
        UPDATE anchor
        SET Anchor_Status = 'Unknown'
        WHERE Anchor_ID IN (
            SELECT anchor.Anchor_ID
            FROM anchor
            JOIN room ON anchor.Room_ID = room.Room_ID
            JOIN place ON room.Place_ID = place.Place_ID
            JOIN plant ON place.Plant_ID = plant.Plant_ID
            JOIN server ON plant.Server_ID = server.Server_ID
            WHERE server.Server_ID = NEW.Server_ID
        );
    END IF;
END;

