create definer = root@localhost trigger server_before_update
    before update
    on server
    for each row
BEGIN
    -- Save current data to anchor_history
		INSERT INTO server_history (Server_ID, Server_Name, Server_Status)
		VALUES (OLD.server_ID, OLD.server_Name, OLD.Server_Status);
    -- The actual update on the anchor table occurs after this trigger
END;

